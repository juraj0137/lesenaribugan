<?

$to = "lesenari@centrum.cz";
$subject = "LešenáriBugáň.cz - Objednavka z WEB stranky";
$message = "
<html>
<head>
  <title>Objednavka zo stranky</title>
</head>
<style type='text/css'>
body {max-width: 768; background-color: #DCEDFF; margin: 0 auto}
p {padding: 10px 10px 0px 10px; margin-left: 30px}
table {border-top: 1px solid black; border-bottom: 1px solid black; background-color: #E1FFD8;}
table td {padding: 5px 20px 5px 5px}
</style>
<body>
  <p>Zo stranky bol odoslany formular s tymito udajmi:</p>
  <table border='0'>
    <tr>
      <td>Kontakt:</td>   <td><b>".$_POST['meno']."</b></td>
    </tr>
    <tr>
      <td>Email:</td>   <td><b>".$_POST['email']."</b></td>
    </tr>
    <tr>
      <td>Cislo:</td>   <td><b>".$_POST['cislo']."</b></td>
    </tr>
    <tr>
      <td>Mnozstvo lesenia a miesto:</td>   <td>".$_POST['mnozstvo']."m2    ".$_POST['miesto']."</td>
    </tr>
    <tr>
      <td>Správa:</td>    <td>".$_POST['odkaz']."</td>
    </tr>
  </table>
  <p>Odoslane <b>".date("j F, Y, G:i:s")."</b> zo stranky www.lesenaribugan.cz</p>

</body>
</html>
";

$headers = 'Content-type: text/html; charset=utf8' . "\r\n";
/*$headers .= 'From: LešenáriBugáň.cz' . "\r\n";*/
if($_POST['meno']!="" and $_POST['email']!="" and $_POST['kod']=="leseni"){
  if(mail($to,$subject,$message,$headers)){
    mail("juraj0137@azet.sk",$subject,$message,$headers);
    mail("juraj.alabuk@gmail.com",$subject,$message,$headers);
    header('Location: ./index.php?sekcia=formular&message=Formulář byl úspěšně odeslán!&sent=1');
  }else{
    header('Location: ./index.php?
                      sekcia=formular&
                      meno='.$_POST['meno'].'&
                      email='.$_POST['email'].'&
                      cislo='.$_POST['cislo'].'&
                      mnozstvo='.$_POST['mnozstvo'].'&
                      miesto='.$_POST['miesto'].'&
                      odkaz='.$_POST['odkaz'].'&
                      message=Formulář nebyl úspěšně odeslán, <br>zkontrolujte zda jste zadali všechny povinné údaje!&
                      sent=0');
  }
}else{
  header('Location: ./index.php?
                      sekcia=formular&
                      meno='.$_POST['meno'].'&
                      email='.$_POST['email'].'&
                      cislo='.$_POST['cislo'].'&
                      mnozstvo='.$_POST['mnozstvo'].'&
                      miesto='.$_POST['miesto'].'&
                      odkaz='.$_POST['odkaz'].'&
                      message=Formulář nebyl úspěšně odeslán, <br>zkontrolujte zda jste zadali všechny povinné údaje!&
                      sent=0');
}
?>


