<style type="text/css">
	#kontakt { background-color: #e6e6e6; background: url("./img/bg6.gif") 0px 0px transparent; padding: 50px 0 ; }
	#kontakt .left {float: left; width: 525px; padding-left: 10px}
	#kontakt .left h2{padding-bottom: 20px}
	#kontakt .left li{list-style: none;line-height: 24px}
	#kontakt .right {float: right; height: 267px; width: 230px;}
	#kontakt .right iframe{float: left;padding: 10px 20px 10px 20px}
	#kontakt .right img{float: right; height: 205px; padding: 0px 10px 0px 0px;}
	#kontakt .right h3{float: right; padding-bottom: 10px; text-align: center; width: 100%;}
	#kontakt .mapa {width: 100%; clear: both;}
	#kontakt .mapa h2{ padding: 15px 0 0 0; text-align: center; width: 100%; cursor: pointer;}
	#kontakt .mapa h2:hover{ text-decoration: underline; }
	#kontakt .mapa .google_iframe {padding: 15px 20px 0 20px; text-align: center; width: 728px }
	#kontakt .mapa iframe { background-color: white; padding: 5px; border: 1px solid black; border-radius: 5px }
</style>

<div class="line_top black"></div>
<div id='kontakt'>
	<div class='centrator'>
		<div class="left">
			<h2>Kontaktní osoba</h2>
			<ul>
				<li><b>Bugáň Pavol</b></li>
				<li>Obchodní firma: Pavol Bugáň, Organizačná složka</li>
				<li>F. S.  Tůmy 1202, Orlová Lutyně 735 14</li>
				<li>m: 736 416 507 / 041 904 387 067</li>
				<li>IČ: 268 29 541</li>
				<li>DIČ: CZ7704048451</li>
				<li class='email'>E-mail: <a href="mailto:lesenari@centrum.cz">lesenari@centrum.cz</a></li>
				<li>Zapsaná: Krajský soud v Ostravě - 8, spisová značka: AX846<br><b>Kontaktní adresa: F. S.  Tůmy 1202, Olová-Lutyně 735 14</b></li>
			</ul>
		</div>

		<div class="right">
			<h3>Náš sklad</h3>
			<img src="./img/mapa.png" >
		</div>

		<div class="mapa">
			<h2>Mapa</h2>
			<div class="google_iframe">
				<iframe width="716" height="380" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?ie=UTF8&amp;ll=49.891427,18.564405&amp;spn=0.015289,0.042272&amp;t=h&amp;z=15&amp;output=embed"></iframe><br /><small><a href="https://maps.google.com/maps?ie=UTF8&amp;ll=49.891427,18.564405&amp;spn=0.015289,0.042272&amp;t=h&amp;z=15&amp;source=embed" style="color:#0000FF;text-align:left">Zväčšiť mapu</a></small>
			</div>
		</div>
	</div>
</div>
