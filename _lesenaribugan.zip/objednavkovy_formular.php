<?
	function post_val($value='')
	{
		if(isset($_GET[$value]))echo $_GET[$value];
	}
?>
<style type="text/css">
	#formular .message_green, .message_red {
		font-weight: bold;
		position: absolute;
		z-index: 30;
		background-color: #4ED04E;
		border: 2px solid #A3FFA3;
		padding: 30px 150px;
		margin: -82px 120px;
		border-radius: 10px;
	}

	#formular .message_red {
		background-color: #EB4848;
		border: 3px solid #970000;
		padding: 20px 60px;
	}


</style>
<div class="line_top red"></div>
<div id='formular'>
	<div class='centrator'>
		<h2>Chcete lešení ? ...</h2>
		<div class="container">
			<?
			if( isset($_GET['sent'])) {
				if ( $_GET['sent']==1) {
					echo "<div class='message_green'>";
					post_val('message');
					echo "</div>";
				}else{
					echo "<div class='message_red'>";
					post_val('message');
					echo "</div>";
				}
			} ?>

			</div>
			<form action="mail.php" method="POST">
			<div class="cell1">
				<label for="meno">
					<img class="vykricnik"  src="img/vykricnik.png">
					Jméno:<input type="text" id="meno"  name="meno"  value="<? post_val('meno');  ?>">
				</label>

				<label for="email">
					<img class="vykricnik"  src="img/vykricnik.png">
					E-mail:<input type="text" id="email" name="email" value="<? post_val('email'); ?>">
				</label>

				<label for="cislo">
					Tel. číslo:	<input type="text" id="cislo" name="cislo" value="<? post_val('cislo'); ?>">
				</label>

			</div>
			<div class="cell2">
				<label for="mnozstvo">Odhadované množství: <input type="text" id="mnozstvo" name="mnozstvo" value="<? post_val('mnozstvo'); ?>">m<sup>2</sup></label>
				<label for="miesto">Místo stavby: <input type="text" id="miesto" name="miesto" value="<? post_val('miesto'); ?>"></label>
				<label for="kod">
					<img class="vykricnik"  src="img/vykricnik.png">
					Opište slovo "<span class="kod">inesel</span>" <input type="text" id="kod" name="kod" >
				</label>

			</div>
			<div class="cell3">
				<img src="img/list.png" alt="">
			</div>
			<label for="odkaz"><div>Vzkaz pro nás: </div><textarea id="odkaz" name="odkaz" value="<? post_val('odkaz'); ?>"></textarea> </label>
			<small><em><img class="vykricnik"  src="img/vykricnik.png"> povinné údaje</em></small><br>
			<small><em>*uvedené údaje jsou pouze informační a nezávazné, po odeslání formuláře Vás budeme kontaktovat</em></small>
			<label for="submit"><input type="submit" value="Odeslat" class="button"></label>
			</form>
		</div>
	</div>
</div>
