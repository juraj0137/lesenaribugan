<style type="text/css">
	#footer {
		background-color: #000;
		background-color: #131313;
		overflow: hidden;
		padding: 35px 0;
		font-family: "Arial", "Helvetica", sans-serif;
		color: #AAAAAA;
		font-size: 12px;
		line-height: 1.5em;
	}

	#footer nav {
		float: left;
		padding: 0 10px 0 10px;
		width: 170px;
	}

	#footer nav h4 {
		color: #990000;
		font-size: 14px;
		font-weight: 700;
		margin-bottom: 1em;
	}

	#footer nav a {
		color: #AAAAAA;
		text-decoration: none;
		cursor: pointer;
	}
	#footer nav a:hover { text-decoration: underline; }

	#footer nav ul li {
		list-style: none outside none;
		margin: 0px;
		padding: 0px;
	}

	#footer .top{ height: 158px; }

	.copyright {
		border-radius: 5px;
		color: #000000 ;
		font-size: 13px;
		padding: 8px ;
		text-align: center;
		background-color: #FFFFCC;
		border: 1px solid #FFD385;
		width: 730px;
		margin: 0 10px;
		margin-top: 25px;
	}

</style>
<div class="line_top white"></div>
<div id='footer'>
	<div class='centrator'>
		<div class="top">
			<nav>
				<h4>Nabízíme</h4>
				<ul>
					<li>Montáž lešení</li>
					<li>Demontáž lešení</li>
					<li>Úklidové práce</li>
					<li>Zámečnické práce</li>
					<li>Zednické práce</li>
					<li><a href="sluzby.php">Více...</a></li>
				</ul>
			</nav>
			<nav>
				<h4>Používáme lešení</h4>
				<ul>
					<li>Trubkové</li>
					<li>Layher</li>
					<li>Sprint</li>
					<li>Peri</li>
				</ul>
			</nav>
			<nav>
				<h4>Kde nás znají</h4>
				<ul>
					<li>Třinecké železárny</li>
					<li>Arcelor Mittal Ostrava</li>
					<li>USSteel Košice</li>
					<li>Biocel Paskov</li>
					<li><a href="referencie2.php">Více...</a></li>
				</ul>
			</nav>
			<nav>
				<h4>Kontakt</h4>
				<ul>
					<li>Pavol Bugáň</li>
					<li>F. S. Tůmy 1202</li>
					<li>Orlová Lutyně</li>
					<li>735 14</li>
					<li>m: 736 416 507</li>
					<li>m: 041 904 387 067</li>
					<li>lesenari@centrum.cz</li>
				</ul>
			</nav>
		</div>

		<div class="copyright"><strong>Lešenári Bugáň / lesenari@centrum.cz</strong> - 1993 - 2013 © Všechna práva vyhrazena</div>

		<div style="display:none">
	        Friends:
	        <a href="http://www.lesenaribugan.cz">LesenariBugan.cz - Oficiálne stránky firmy Lesenári Bugan</a>
	        <a href="http://www.therebels.sk">TheRebels.sk - Hudobná skupina The Rebels</a>
	        <a href="http://www.fifaliga.php5.sk">Stránky autora - Fifa liga - Juraj Kubala</a>
      </div>
	</div>
</div>
