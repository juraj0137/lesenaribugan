<div id='sluzby'>
	<div class='centrator'>
		<div class="ponuka">
			<h2>Co nabízíme…</h2>
			<ul>
				<li>Montáž a demontáž lešení</li>
				<li>Natěračské a malířské práce</li>
				<!-- <li>Úklidové práce</li> -->
				<li>Zámečnické práce</li>
				<li>Zednické práce</li>
				<li>Demoliční práce</li>
				<li><a href="sluzby.php" class="button">Více ...</a></li>

				<!-- Dle pozadavku zakazniku sme schopny dodat k leseni staticky vypocet a projekt leseni -->
			</ul>
		</div>
		<div class="galeria">
			<!-- <img class="curr_img" src="img/galeria/lesenie01_big.jpg"> -->
			<img class="curr_img" src="img/referencie/biocel_paskov_01.jpg">
			<div class="sidebar">
				<ul>
					<!-- <li><img src="img/galeria/lesenie01.jpg" alt="" class="side"></li>
					<li><img src="img/galeria/lesenie02.jpg" alt="" class="side"></li>
					<li><img src="img/galeria/lesenie03.jpg" alt="" class="side"></li>
					<li><img src="img/galeria/lesenie02.jpg" alt="" class="side"></li> -->

					<li><img class="side" src="img/referencie/tatra_koprivnice_01.jpg" title="Tatra Kopřivnice">		</li>
					<li><img class="side" src="img/referencie/borsodchem_01.jpg" title="BorsodChem">					</li>
					<li><img class="side" src="img/referencie/bonatrans_01.jpg" title="Bonatrans Bohumín">				</li>
					<!--li class=""><img src="img/referencie/"></li-->
					<li><img class="side" src="img/referencie/cez_01.jpg" title="ČEZ, a.s.">							</li>
					<li><img class="side" src="img/referencie/arcelor_mittal_01.jpg" title="Arcellor Mittal">			</li>
					<li><img class="side" src="img/referencie/biocel_paskov_01.jpg" title="BIOCEL Paskov">				</li>
					<li><img class="side" src="img/referencie/trinecke_zelezarny_01.jpg" title="Třinecké železárny">	</li>
					<li><img class="side" src="img/referencie/us_steel_kosice_03.jpg" title="US Steel Košice">			</li>
					<li><img class="side" src="img/referencie/okd_dul_darkov_02.jpg" title="OKD Dúl Darkov">			</li>

				</ul>
			</div>
		</div>
	</div>
</div>
