<style type="text/css">
	#cennik {background-color: #76CFF8; padding: 40px 0}
	#cennik h2{margin: -5px 0px -5px 0px; padding: 0px 0px 0px 30px; width: 120px; cursor: pointer}
	#cennik h2:hover{text-decoration: underline;}
	#cennik h3{font-size: 20px; padding: 0px 0px 15px;}

	#cennik .main{background-color: #b0e1f8; border: 1px solid #248EBF; border-radius: 5px; padding: 30px;margin: 30px 10px 0 10px}
	#cennik .main p {line-height: 25px; padding-left: 10px}
</style>

<div class="line_top black cennik"></div>
<div id='cennik'>
	<div class='centrator'>
		<h2>Ceník</h2>
		<div class="main">
			<h3>Pronájem, montáž, demontáž lešení</h3>
			<p>Po obhlídce stavby naším pracovníkem budeme kontaktovat zákazníka, a individuálně se domluvíme na cenách za pronájem, montáž, demontáž lešení a jiné poskytované služby.</p>
		</div>
	</div>
</div>
<div class="line_bottom black cennik"></div>
