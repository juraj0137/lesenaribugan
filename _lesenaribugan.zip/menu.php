<style type="text/css">
	#fixed_menu {
		background-color: #373633;
		font-family: "PT Sans", sans-serif;
		height:45px;
		position: fixed;
		z-index: 99;
		width: 100%;
		display: none;
		/*padding-bottom: 29px; /* dokopy je vyska 75px */
	}

	#fixed_menu h1 {
		color: white;
		font-size: 20px;
		line-height: 20px;
		float: left;
		padding: 13px 0px 0px 10px
	}

	#fixed_menu nav {
		font-size: 14px;
		font-weight: 700;
		text-transform: uppercase;
		float: right;
		padding: 15px 10px 0 0;
	}

	#fixed_menu ul {
		list-style: none;
		display: inline;
	}

	#fixed_menu li {
		float: left;
		margin-left: 10px;
	}

	#fixed_menu a {
		color: white;
		text-decoration: none
	}

	#fixed_menu a:hover {
		color:#F15654
	}

	#fixed_menu a.button{
		font-size: 14px;
	}
</style>

<header id='fixed_menu'>
	<div class='centrator'>
		<h1><a href="index.php"> LešenáriBugáň.cz</a></h1>
		<nav>
			<ul>
				<li><a href='#menu'><img src="img/home.png" alt="" style="height: 36px; margin-top: -13px"> </a></li>
				<li><a href='#sluzby'>nabídka</a></li>
				<li><a href='#referencie'>reference</a></li>
				<li><a href='#kontakt'>kontakt</a></li>
				<li><a href='#formular' class='button'>objednávka</a></li>
				<a href="#menu"><img src="img/sipka.png" id="up" alt="Hore"></a>
			</ul>
		</nav>
	</div>
</header>

<header id='menu'>
	<div class='centrator'>
		<h1><a href="index.php"> LešenáriBugáň.cz</a></h1>
		<nav>
			<ul>
				<li><a href='#menu'><img src="img/home.png" alt="" style="height: 40px; margin-top: -13px"> </a></li>
				<li><a href='#sluzby'>nabídka</a></li>
				<li><a href='#referencie'>reference</a></li>
				<li><a href='#kontakt'>kontakt</a></li>
				<li><a href='#formular' class='button'>objednávka</a></li>
			</ul>
		</nav>
	</div>
</header>


