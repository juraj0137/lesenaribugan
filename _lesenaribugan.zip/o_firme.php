<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8'>
	<link rel="stylesheet" href="assets/style.css">
	<script src="assets/jquery.js"></script>
	<script src="assets/jquery.cycle.js"></script>
	<title>Oficiální stránka - Lešenáři Bugáň - O firmě</title>
</head>

<script type="text/javascript">
	$(function(){
		$('img,body').hide();
		$('body').fadeIn(500);
		$('img').fadeIn(1500);
	})
</script>
<style type="text/css">
	#o_firme {
		background-color: #e6e6e6;
		background-color: #b0e1f8;
		background: url("./img/bg6.gif") 0px 0px transparent;
		padding: 60px 0 70px 0px;
		height: 547px;
	}

	#o_firme div>p {
		line-height: 25px;
		font-size: 18px;
		padding: 10px;
	}

	#o_firme h2 {
		font-size: 40px;
		padding-left: 40px;
		padding-bottom: 20px;
	}

	#o_firme ul {
		margin: 0px 0px 0px 100px;
	}

	#o_firme li {
		line-height: 25px
	}

	#o_firme img {
		background-color: white;
		float: right;
		width: 300px;
		padding: 5px;
		margin: 20px;
		border: 1px solid #333;
	}
	#o_firme .button_red{
		color: red;
		text-decoration: none;

	}
	#o_firme .button_red:hover{
		color: #FE433A;
	}
</style>


<body>
<?php
//menu
include_once("assets/analyticstracking.php");
include('menu2.php');
?>
<div class="line_top black"></div>
<div id='o_firme'>
	<div class='centrator'>
		<img src="./img/lesenar.jpg">
		<h2>Vítejte u nás</h2>
		<p>Naše společnost provádí speciální lešenářské práce, práce ve výškách, malířské práce, zednické práce a mnoho jiného. Naši zkušení pracovníci kompletně zajistí stavbu lešení, dovoz a odvoz materiálu ze stavby. Pracujeme s různými typy lešení v závislosti na typu a charakteru požadavek.</p>
		<p>Pro stavbu pracujeme s <b>trubkovým lešením</b>, lešením <b>Layher</b>,<b> Sprint</b> a <b>Peri</b>. Naši dominantou je <b>trubkové lešení</b>, které montujeme jako:
			<ul>
				<li>Závěsné  lešení</li>
				<li>Řádově  lešení</li>
				<li>Prostorové  lešení</li>
				<li>Vysunuté lešení</li>
			</ul>
		</p>
		<p>Působíme hlavně v <b>Moravskoslezském kraji</b> nebo dle požadavků zákazníka </p>
		<p>
			Těšíme se na spolupráci s Vámi. Kontaktovat nás můžete přes  <b><a href="index.php?sekcia=formular" class="button_red">kontaktní formulář.</a></b>
		</p>
	</div>
</div>
<div class="line_bottom black"></div>
<?
//footer
include('footer.php');
?>

</body>
</html>