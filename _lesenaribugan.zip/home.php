
<div class="line_top black"></div>
<div id='intro'>
	<div class='centrator'>
		<h2>Potřebujete postavit průmyslové lešení ?<br> Tady jste na správném místě ! </h2>
		<img src="img/home_02.jpg">
		<p>Jsme firma, která se postará o bezproblémové postavení lešení, demontáž, a mnoho jiných prací. Těšíme se na spolupráci s Vámi.<br><a class="button" href="./o_firme.php">Více o firmě ...</a></p>
	</div>
</div>
<div class="line_bottom black"></div>