<style type="text/css">
	#fixed_menu2 {
		background-color: #373633;
		font-family: "PT Sans", sans-serif;
		height:45px;
		position: fixed;
		z-index: 99;
		width: 100%;
		display: none;
	}

	#fixed_menu2 h1 {
		color: white;
		font-size: 20px;
		line-height: 20px;
		float: left;
		padding: 13px 0px 0px 10px
	}

	#fixed_menu2 nav {
		font-size: 14px;
		font-weight: 700;
		text-transform: uppercase;
		float: right;
		padding: 15px 10px 0 0;
	}

	#fixed_menu2 ul {
		list-style: none;
		display: inline;
	}

	#fixed_menu2 li {
		float: left;
		margin-left: 10px;
	}

	#fixed_menu2 a {
		color: white;
		text-decoration: none
	}

	#fixed_menu2 a:hover {
		color:#F15654
	}

	#fixed_menu2 a.button{
		font-size: 14px;
	}
</style>

<header id='fixed_menu2'>
	<div class='centrator'>
		<h1><a href="index.php"> LešenáriBugáň.cz</a></h1>
		<nav>
			<ul>
				<li><a href='index.php'><img src="img/home.png" alt="" style="height: 36px; margin-top: -13px"> </a></li>
				<li><a href='index.php?sekcia=sluzby'>nabídka</a></li>
				<li><a href='index.php?sekcia=referencie'>reference</a></li>
				<li><a href='index.php?sekcia=kontakt'>kontakt</a></li>
				<li><a href='index.php?sekcia=formular' class='button'>objednávka</a></li>
			</ul>
		</nav>
	</div>
</header>

<header id='menu'>
	<div class='centrator'>
		<h1><a href="index.php"> LešenáriBugáň.cz</a></h1>
		<nav>
			<ul>
				<li><a href='index.php'><img src="img/home.png" alt="" style="height: 36px; margin-top: -13px"> </a></li>
				<li><a href='index.php?sekcia=sluzby'>nabídka</a></li>
				<li><a href='index.php?sekcia=referencie'>reference</a></li>
				<li><a href='index.php?sekcia=kontakt'>kontakt</a></li>
				<li><a href='index.php?sekcia=formular' class='button'>objednávka</a></li>
			</ul>
		</nav>
	</div>
</header>


