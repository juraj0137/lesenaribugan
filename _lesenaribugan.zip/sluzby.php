<!DOCTYPE html>
<html>
<meta charset='utf-8'>
<link rel="stylesheet" href="assets/style.css">
<script src="assets/jquery.js"></script>
<script src="assets/jquery.cycle.js"></script>

<head>
	<title>Oficiální stránka - Lešenáři Bugáň - Služby</title>
</head>

<script type="text/javascript">
	$(function(){
		$('img,body').hide();
		$('body').fadeIn(500);
		$('img').fadeIn(1500);
	})
</script>
<style type="text/css">
	#sluzby_php {background-color: #b0e1f8; background: url("./img/bg6.gif") 0px 0px transparent; padding: 60px 0 70px 0px; /*height: 430px;*/ font-weight: 300; }
	#sluzby_php h2 {padding: 0 0 20px 40px}
	#sluzby_php p {}
	#sluzby_php ul {padding: 10px 0 0 20px; line-height:25px}
	#sluzby_php .wrapper_1 {float: left; height: inherit; padding-left: 10px; width: 447px; }
	#sluzby_php .wrapper_2 {float: right; height: inherit; padding-right: 10px; width: 280px; }
	#sluzby_php .clear {width: 100%; clear: both;}

</style>
<body>
<?php
//menu
include('menu2.php');
include_once("assets/analyticstracking.php");
?>
<div class="line_top black"></div>
<div id='sluzby_php'>
	<div class='centrator'>
		<h2>Předmět činností</h2>
		<div class="wrapper_1">
			<p>Zajišťujeme tyto práce, včetně dodání potřebného materiálu:</p>
			<ul>
				<li>lešenářské práce</li>
				<li>malířské práce</li>
				<li>natěračské práce</li>
				<li>přípravné práce pro stavbu: tryskání, úklidové a čistící práce</li>
				<li>zámečnické práce</li>
				<li>zednické práce</li>
				<li>čištění jímek, kotlů a zásobníků surového uhlí</li>
				<li>demoliční práce</li>
			</ul>
		</div>
		<div class="wrapper_2">
			<p>Lešení montujeme:</p>
			<ul>
				<li>v nádržích</li>
				<li>v teplárenských kotlech</li>
				<li>v elektrárenských kotlech</li>
				<li>ve vysokých pecí</li>
				<li>na železničních a potrubních mostech</li>
				<li>k potrubím</li>
				<li>ve výsypkách surového uhlí</li>
				<li>k ocelovým konstrukcím</li>
				<li>k těžním věžím</li>
				<li>k rodinným domům</li>
				<li>k panelákům</li>
			</ul>
		</div>
		<div class="clear"></div>


	</div>
</div>
<div class="line_bottom black"></div>
<?
//footer
include('footer.php');
?>

</body>
</html>