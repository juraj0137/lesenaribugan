<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8'>
	<meta name="language" content="czech">
	<meta name="google-site-verification" content="lHPqywn05CuT3o7eWlek-udk_IBH-cHU8nll3-xBEjE" />
	<link rel="stylesheet" href="assets/style.css">
	<script src="assets/jquery.js"></script>
	<script src="assets/javascript.js"></script>
	<script src="assets/jquery.cycle.js"></script>
	<title>Oficiální stránka - Lešenáři Bugáň</title>
</head>
<body>
	<?php
		include_once("assets/analyticstracking.php");
		include('assets/php.php');

		//menu
		include('menu.php');

		//home
		include('home.php');

		//co ponukame + galeria
		include('sluzby_galeria.php');

		//referencie
		include('referencie.php');

		//objednavkovy formular
		include('objednavkovy_formular.php');

		//cennik
		include('cennik.php');

		//kontakt
		include('kontakt.php');

		//footer
		include('footer.php');
	?>
</body>
</html>
