<div class="line_top black"></div>
<div id='referencie'>
	<div class='centrator'>
		<div class="container">
			<ul class="slideshow">
				<li><img src="img/referencie/okd_dul_darkov_02.jpg" > 		<h3>OKD Dúl Darkov</h3>		</li>
				<li><img src="img/referencie/us_steel_kosice_03.jpg" > 		<h3>US Steel Košice</h3>	</li>
				<li><img src="img/referencie/trinecke_zelezarny_01.jpg" > 	<h3>Třinecké železárny</h3>	</li>
				<li><img src="img/referencie/biocel_paskov_01.jpg" > 		<h3>BIOCEL Paskov</h3>		</li>
				<li><img src="img/referencie/arcelor_mittal_01.jpg" > 		<h3>Arcellor Mittal</h3>	</li>
				<li><img src="img/referencie/cez_01.jpg" > 					<h3>ČEZ, a.s.</h3>			</li>
				<li><img src="img/referencie/bonatrans_01.jpg" > 			<h3>Bonatrans Bohumín</h3>	</li>
				<li><img src="img/referencie/borsodchem_01.jpg" > 			<h3>BorsodChem</h3>			</li>
				<li><img src="img/referencie/tatra_koprivnice_01.jpg" > 	<h3>Tatra Kopřivnice</h3>	</li>
			</ul>
		</div>
		<img class="kladivo" src="img/kladivo.png" alt="">
		<div class="zoznam">
			<h2>Kde jsme stavěli…</h2>
			<ul>
				<li>US Steel Košice</li>
				<li>Třinecké železárny</li>
				<li>Arcellor Mittal Ostrava</li>
				<li>BIOCEL Paskov</li>
				<li>Bohumín Bonatrans</li>
				<li><a href="referencie2.php" class="button">Více ...</a></li>
			</ul>
		</div>

	</div>
</div>