<!DOCTYPE html>
<html>
<head>
	<meta charset='utf-8'>
	<link rel="stylesheet" href="assets/style.css">
	<script src="assets/jquery.js"></script>
	<script src="assets/jquery.cycle.js"></script>
	<title>Oficiální stránka - Lešenáři Bugáň - Reference</title>
</head>
<script type="text/javascript">
	$(function(){
		$('img,body').hide();
		$('body').fadeIn(500);
		$('img').fadeIn(1500);

		//galeria - slide sidebar

		function slide () {
			var side_ul = $('.wrap_2').find('ul');
			side_ul.delay('2000').animate({left: - 111},2000,function(){
				side_ul.css({left: 0}).find('li:first').detach().appendTo(side_ul);
				slide();
			});
		};
		slide();

		//referencie  - mainslide


		function slide_left () {
			var ul = $('.wrap_1').find('ul');
			ul.animate({left: - 668},700,function(){
				ul.css({left: 0}).find('li:first').detach().appendTo(ul);
			});
		};

		function slide_right () {
			var ul = $('.wrap_1').find('ul');
			ul.find('li:last').detach().prependTo(ul);
			ul.css({left: -668}).animate({left:0},700);
		};

		$('.left img').click(function(){ slide_right(); });
		$('.right img').click(function(){ slide_left(); });

		var class_id
		function class_position (class_id) {
			var ul = $('.wrap_1').find('ul');
			var el_left = $('.wrap_1 ul').find('li[class='+class_id+']').position().left;

			ul.animate({left:-el_left},700);
			ul.css({left: 0});
		};

		$('.wrap_2 ul li img').click(function() {
			var cl_id = $(this).attr('class');
			console.log('class: '+cl_id);
			class_position(cl_id);
		});

		 /**
		 **	Referencie tabulka
		 **/

 			var referencie_table = $('.wrapper_table');
 			var h3_button = $('.wrapper h3');

 			referencie_table.hide();
 			h3_button.click(function  () {
 				referencie_table.slideToggle('slow');
 			});

	})
</script>

<style type="text/css">
	#ref {background-color: #b0e1f8; background: url("./img/bg6.gif") 0px 0px transparent; padding: 60px 0 70px 0px; /*height: 430px;*/ }

	#ref .wrap_1 {padding: 0 10px; margin: 0 auto; height: 320px}
	#ref .wrap_1 .left,.current,.right{float: left;}
	#ref .wrap_1 .left, .right { width:  45px; height: inherit; vertical-align: middle;}
	#ref .wrap_1 .left  {text-align: left; }
	#ref .wrap_1 .right {text-align: right; }

	#ref .wrap_1 .left img, .right img { height: 30px; padding: 145px 4px 0 4px; cursor: pointer; }
	#ref .wrap_1 .left img:hover, .right img:hover { height: 32px; padding: 144px 0 0 0; }

	#ref .wrap_1 .current {width:  658px; height: inherit;  position: relative;overflow: hidden;}
	#ref .wrap_1 .current img{background-color: white; padding: 4px; margin-right: 20px; border: 1px solid black; width: 420px; height: 310px; float: left;}
	#ref .wrap_1 .current h2{padding: 60px 0 30px 0;}
	#ref .wrap_1 .current p{line-height: 25px; padding-top: 10px}

	#ref .wrap_1 ul{list-style: none; position: absolute; height: inherit; display: inline; width: 45000px }
	#ref .wrap_1 li {float: left; margin-right: 10px; width: 658px;}


	#ref .wrap_2 {padding: 10px 0; margin: 10px auto; height: 79px; width: 658px; border-top: 1px dotted black; position: relative; overflow: hidden; }
	#ref .wrap_2 ul {list-style: none; position: absolute; display: inline; height: 80px; width: 9000px}
	#ref .wrap_2 ul li:last-child {margin-right: 0}
	#ref .wrap_2 li {float: left;margin-right: 8px; cursor: pointer; height: 80px}
	#ref .wrap_2 li img {background-color: white; padding: 2px; border: 1px solid silver; width: 97px; height: 75px }
	#ref .wrap_2 li img:hover {border: 1px solid black; }

	#ref .wrap_3 { padding: 10px}
	#ref .wrap_3 .wrapper {background-color: #CCEDFC; border: 1px solid #248EBF; border-radius: 5px; padding: 10px 20px;margin-top: 20px}
	#ref .wrap_3 .wrapper h3 { padding: 10px 0px 10px 0px; width: 100%; text-align: center; cursor: pointer}
	#ref .wrap_3 .wrapper h3:hover { text-decoration: underline;}
	#ref .wrap_3 table { font-size: 14px; width: 100%; margin-top:10px;}
	#ref .wrap_3 table tr { background:#CCEDFC;}
	#ref .wrap_3 table tr.modra { background:#93DDFF;}
	#ref .wrap_3 table td {padding: 5px 0px 5px 5px;}


</style>
<body>
<?php
//menu
include('menu2.php');
include_once("assets/analyticstracking.php");
?>
<div class="line_top black"></div>
<div id='ref'>
	<div class='centrator'>
		<div class="wrap_1">
			<div class="left"><img src="img/arrow_left.png"></div>
			<div class="current">
				<ul>
					<li class="1">
						<img src="img/referencie/okd_dul_darkov_02.jpg" alt="OKD Dúl Darkov" title="OKD Dúl Darkov">
						<h2>OKD Dúl Darkov</h2>
						<p>Místo stavby: Karviná</p>
						<p>Dělali jsme nátěr loga DARKOV na skype.</p>
					</li>

					<li class="2">
						<img src="img/referencie/us_steel_kosice_03.jpg" alt="US Steel Košice" title="US Steel Košice">
						<h2>US Steel Košice</h2>
						<p>Místo stavby: Košice </p>
						<p>Dělali jsme generální opravu vysoké pece</p>
					</li>
					<li class="3">
						<img src="img/referencie/trinecke_zelezarny_01.jpg" alt="Třinecké železárny" title="Třinecké železárny">
						<h2 style="font-size: 22px">Třinecké železárny</h2>
						<p>Místo stavby: Třinec </p>
						<p>Stavěli jsme lešení k různým potrubím a zásobníkúm.</p>
					</li>
					<li class="4">
						<img src="img/referencie/biocel_paskov_01.jpg" alt="BIOCEL Paskov" title="BIOCEL Paskov">
						<h2>BIOCEL Paskov</h2>
						<p>Místo stavby: Paskov</p>
						<p>Stavěli jsme lešení v regeneračním kotli, lešení k potrubím, fasádne lešení.</p>
					</li>
					<li class="5">
						<img src="img/referencie/arcelor_mittal_01.jpg" alt="Arcellor Mittal" title="Arcellor Mittal">
						<h2>Arcellor Mittal</h2>
						<p>Místo stavby: Ostrava</p>
						<p>Stavěli jsme lešení k prúmyslovým jeřábum, lešení k vzduchotechnice, dělali jsme opravárenské práce na turbíne.</p>
					</li>
					<li class="6">
						<img src="img/referencie/cez_01.jpg" alt="ČEZ, a.s." title="ČEZ, a.s.">
						<h2>ČEZ, a.s.</h2>
						<p>Místo stavby: Dětmarovice</p>
						<p>Stavěli jsme lešení k vzduchovodom, lešení v hlubinném zásobníku a lešení ke kotli na GO.</p>
					</li>
					<!--li class="">
						<img src="img/referencie/">
						<h2>Dalkia</h2>
						<p>Místo stavby: ??????</p>
						<p>Stavěli jsme lešení v spalovací komoře K2, čistili jsme kotle K1,K2,K3,K4, stavěli lešení v rámci GO TG4. </p>
					</li-->
					<li class="7">
						<img src="img/referencie/bonatrans_01.jpg" alt="Bonatrans Bohumín" title="Bonatrans Bohumín">
						<h2 style="font-size: 22px">Bonatrans Bohumín</h2>
						<p>Místo stavby: Bohumín</p>
						<p>Stavěli jsme lešení k jeřábové dráze, rúzna lešení v halách a k potrubím.</p>
					</li>
					<li class="8">
						<img src="img/referencie/borsodchem_01.jpg" alt="BorsodChem" title="BorsodChem">
						<h2>BorsodChem</h2>
						<p>Místo stavby: Ostrava </p>
						<p>Dělali jsme lšení na mostě A6 a A8.</p>
					</li>
					<li class="9">
						<img src="img/referencie/tatra_koprivnice_01.jpg" alt="Tatra Kopřivnice" title="Tatra Kopřivnice">
						<h2>Tatra Kopřivnice</h2>
						<p>Místo stavby: Kopřivnice</p>
						<p>Dělali jsme vymalovaní správní budovy, opravu a pokládku dlažby na strojovně.</p>
					</li>

				</ul>
			</div>
			<div class="right"><img src="img/arrow_right.png"></div>
		</div>
		<div class="wrap_2">
			<ul>
					<li><img class="1" src="img/referencie/okd_dul_darkov_02.jpg" title="OKD Dúl Darkov">			</li>
					<li><img class="2" src="img/referencie/us_steel_kosice_03.jpg" title="US Steel Košice">			</li>
					<li><img class="3" src="img/referencie/trinecke_zelezarny_01.jpg" title="Třinecké železárny">	</li>
					<li><img class="4" src="img/referencie/biocel_paskov_01.jpg" title="BIOCEL Paskov">				</li>
					<li><img class="5" src="img/referencie/arcelor_mittal_01.jpg" title="Arcellor Mittal">			</li>
					<li><img class="6" src="img/referencie/cez_01.jpg" title="ČEZ, a.s.">							</li>
					<!--li class=""><img src="img/referencie/"></li-->
					<li><img class="7" src="img/referencie/bonatrans_01.jpg" title="Bonatrans Bohumín">				</li>
					<li><img class="8" src="img/referencie/borsodchem_01.jpg" title="BorsodChem">					</li>
					<li><img class="9" src="img/referencie/tatra_koprivnice_01.jpg" title="Tatra Kopřivnice">		</li>
			</ul>
		</div>
		<div class="wrap_3">
			<? include("referencie_table.html"); ?>
		</div>
	</div>
</div>
<div class="line_bottom black"></div>
<?
//footer
include('footer.php');
?>

</body>
</html>